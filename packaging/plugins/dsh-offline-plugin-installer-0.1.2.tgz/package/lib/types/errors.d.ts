/** Stable browser-facing failure categories. */
export type InstallerErrorCode = 'ABORTED' | 'BUSY' | 'FORBIDDEN' | 'INSTALL_FAILED' | 'INSTALL_TIMEOUT' | 'INVALID_ARCHIVE' | 'INVALID_REQUEST' | 'METHOD_NOT_ALLOWED' | 'NOT_FOUND' | 'PACKAGE_INCOMPATIBLE' | 'STORE_FULL' | 'UPLOAD_TOO_LARGE';
/** Expected failure with an intentionally bounded public message. */
export declare class InstallerError extends Error {
    readonly code: InstallerErrorCode;
    readonly status: number;
    /**
     * @param code - Stable machine-readable category.
     * @param status - HTTP status for the Web route.
     * @param message - User-safe message without local paths or secrets.
     * @param cause - Optional internal failure retained for Host diagnostics.
     */
    constructor(code: InstallerErrorCode, status: number, message: string, options?: {
        readonly cause?: unknown;
    });
}
/** Normalize cancellation from streams and subprocesses. */
export declare function abortedError(cause?: unknown): InstallerError;
/** Preserve expected failures and hide implementation details from all others. */
export declare function publicInstallerError(error: unknown): InstallerError;
//# sourceMappingURL=errors.d.ts.map