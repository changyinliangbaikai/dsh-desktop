/** Read route for a fresh per-process installation token. */
export declare const INSTALLER_SESSION_ROUTE = "/dsh-offline-plugin-installer/session.json";
/** Raw npm tarball mutation route. */
export declare const INSTALLER_UPLOAD_ROUTE = "/dsh-offline-plugin-installer/install.tgz";
//# sourceMappingURL=paths.d.ts.map