/** Validation policy tied to the running DSH deployment. */
export interface ArchivePolicy {
    readonly maxUploadBytes: number;
    readonly maxExpandedBytes: number;
    readonly maxArchiveEntries: number;
    readonly expectedHarnessVersion: string;
    readonly expectedCordisVersion: string;
    readonly allowedPackagePrefixes: readonly string[];
}
/** Trusted manifest projection after the complete tar stream has been checked. */
export interface ArchiveInspection {
    readonly name: string;
    readonly version: string;
    readonly sha256: string;
    readonly archiveBytes: number;
    readonly expandedBytes: number;
    readonly entryCount: number;
    readonly runtimeDependencies: readonly string[];
}
/** Inspect an npm gzip tarball without extracting it to disk. */
export declare function inspectArchive(path: string, policy: ArchivePolicy, signal?: AbortSignal): Promise<ArchiveInspection>;
//# sourceMappingURL=inspect.d.ts.map