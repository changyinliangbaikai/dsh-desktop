/** Bounded process result retained only for Host diagnostics. */
export interface CliResult {
    readonly exitCode: number | null;
    readonly signal: NodeJS.Signals | null;
    readonly stdout: string;
    readonly stderr: string;
    readonly timedOut: boolean;
}
/** Inputs for invoking the same published DSH CLI that owns plugin reconciliation. */
export interface CliRunnerOptions {
    readonly cliEntryPath: string;
    readonly profile: string;
    readonly profileDir: string;
    readonly timeoutMs: number;
    readonly maxOutputBytes: number;
    readonly platform?: NodeJS.Platform;
    readonly executablePath?: string;
    readonly environment?: NodeJS.ProcessEnv;
}
/** Resolve and validate the current or explicitly configured DSH CLI entry. */
export declare function resolveCliEntryPath(configured: string): string;
/** Own at most one recursive DSH CLI process and its cancellation lifecycle. */
export declare class DshCliRunner {
    #private;
    constructor(options: CliRunnerOptions);
    /** Add one persistent local tarball with network and lifecycle scripts disabled. */
    add(archivePath: string, signal: AbortSignal): Promise<CliResult>;
    /** Stop an active package manager tree before Cordis unload completes. */
    dispose(): Promise<void>;
}
//# sourceMappingURL=cli-runner.d.ts.map