import z from '@deepseek-ai/schemastery';
export declare const DEFAULT_CONFIG: Readonly<{
    profile: "web";
    archiveStoreDir: ".dsh-offline-plugin-packages";
    cliEntryPath: "";
    maxUploadBytes: number;
    maxExpandedBytes: number;
    maxArchiveEntries: 10000;
    maxStoredPackages: 128;
    maxStoredBytes: number;
    installTimeoutMs: number;
    maxCliOutputBytes: number;
    expectedHarnessVersion: "0.1.2-rc.1";
    expectedCordisVersion: "4.0.2";
    allowedPackagePrefixes: readonly string[];
}>;
/** Loader config before Schemastery supplies package defaults. */
export interface Config {
    profile?: string;
    archiveStoreDir?: string;
    cliEntryPath?: string;
    maxUploadBytes?: number;
    maxExpandedBytes?: number;
    maxArchiveEntries?: number;
    maxStoredPackages?: number;
    maxStoredBytes?: number;
    installTimeoutMs?: number;
    maxCliOutputBytes?: number;
    expectedHarnessVersion?: string;
    expectedCordisVersion?: string;
    allowedPackagePrefixes?: string[];
}
/** Complete runtime configuration with resolved Profile and store paths. */
export interface ResolvedConfig {
    readonly profile: string;
    readonly profileDir: string;
    readonly archiveStoreDir: string;
    readonly archiveStorePath: string;
    readonly cliEntryPath: string;
    readonly maxUploadBytes: number;
    readonly maxExpandedBytes: number;
    readonly maxArchiveEntries: number;
    readonly maxStoredPackages: number;
    readonly maxStoredBytes: number;
    readonly installTimeoutMs: number;
    readonly maxCliOutputBytes: number;
    readonly expectedHarnessVersion: string;
    readonly expectedCordisVersion: string;
    readonly allowedPackagePrefixes: readonly string[];
}
export declare const Config: z<Config>;
/** Validate cross-field and filesystem configuration at plugin load. */
export declare function resolveConfig(config: Config): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map