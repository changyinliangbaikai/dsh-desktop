import type { IncomingMessage } from 'node:http';
/** Facts measured while streaming the compressed request body to disk. */
export interface UploadResult {
    readonly bytes: number;
    readonly sha256: string;
}
/** Write a request body once while enforcing the compressed-byte ceiling. */
export declare function writeUpload(request: IncomingMessage, path: string, maxBytes: number, signal: AbortSignal): Promise<UploadResult>;
//# sourceMappingURL=upload.d.ts.map