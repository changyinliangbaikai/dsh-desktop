import type { IncomingMessage } from 'node:http';
/** Accept only same-origin requests whose HTTP authority is loopback. */
export declare function isTrustedBrowserRequest(request: IncomingMessage): boolean;
/** Compare the per-process mutation token without early-exit byte differences. */
export declare function matchesToken(request: IncomingMessage, expected: string): boolean;
/** Validate the advisory browser filename without using it as a filesystem path. */
export declare function hasTgzFilename(request: IncomingMessage): boolean;
/** Accept only raw gzip/octet-stream bodies; multipart parsing is deliberately absent. */
export declare function hasArchiveContentType(request: IncomingMessage): boolean;
//# sourceMappingURL=security.d.ts.map