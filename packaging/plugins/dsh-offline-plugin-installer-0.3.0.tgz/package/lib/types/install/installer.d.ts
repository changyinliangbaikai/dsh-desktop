import type { InstallSuccessResponse } from '../api/types.js';
import { type ArchivePolicy } from '../archive/inspect.js';
import { ArchiveStore } from '../store/archive-store.js';
import { DshCliRunner } from './cli-runner.js';
/** Minimal logger face used to retain package-manager diagnostics on the Host only. */
export interface InstallerLogger {
    warn(message: string): void;
}
/** Validate, persist, install, and finalize one already bounded request body. */
export declare class OfflinePackageInstaller {
    private readonly policy;
    private readonly store;
    private readonly cli;
    private readonly logger;
    constructor(policy: ArchivePolicy, store: ArchiveStore, cli: Pick<DshCliRunner, 'add' | 'dispose'>, logger: InstallerLogger);
    /** Install one archive through the official DSH CLI. */
    install(incomingPath: string, signal: AbortSignal): Promise<InstallSuccessResponse>;
    /** Stop the subprocess layer during unload. */
    dispose(): Promise<void>;
}
//# sourceMappingURL=installer.d.ts.map