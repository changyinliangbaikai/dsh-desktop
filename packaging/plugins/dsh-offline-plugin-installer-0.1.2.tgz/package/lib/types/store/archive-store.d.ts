import type { ArchiveInspection } from '../archive/inspect.js';
interface PendingRecord {
    readonly packageName: string;
    readonly version: string;
    readonly sha256: string;
    readonly archiveFilename: string;
    readonly archiveBytes: number;
    readonly expandedBytes: number;
    readonly entryCount: number;
    readonly runtimeDependencies: readonly string[];
}
/** Options for the bounded archive store inside one DSH Profile. */
export interface ArchiveStoreOptions {
    readonly profileDir: string;
    readonly storePath: string;
    readonly maxStoredBytes: number;
    readonly maxStoredPackages: number;
}
/** One installed-path reservation that can commit or remove its pending archive. */
export declare class ArchiveReservation {
    #private;
    private readonly store;
    readonly archivePath: string;
    readonly record: PendingRecord;
    private readonly pendingPath;
    private readonly createdArchive;
    constructor(store: ArchiveStore, archivePath: string, record: PendingRecord, pendingPath: string, createdArchive: boolean);
    /** Mark the CLI-installed archive current and prune older versions for this package. */
    commit(): Promise<void>;
    /** Remove an archive that never became a Profile dependency. */
    rollback(): Promise<void>;
}
/** Profile-local durable store with one retained archive per installed package. */
export declare class ArchiveStore {
    #private;
    constructor(options: ArchiveStoreOptions);
    /** Create the store, reject symlink redirection, and recover interrupted installs. */
    initialize(): Promise<void>;
    /** Generate a non-user-controlled incoming file path inside the store. */
    createIncomingPath(): string;
    /** Delete a request body that did not reach archive promotion. */
    discardIncoming(path: string): Promise<void>;
    /** Move a validated incoming archive to its stable hash path and mark it pending. */
    promote(path: string, inspection: ArchiveInspection): Promise<ArchiveReservation>;
    /** Finalize a reservation after the official CLI exits successfully. */
    commit(archivePath: string, record: PendingRecord, pendingPath: string): Promise<void>;
}
export {};
//# sourceMappingURL=archive-store.d.ts.map