import type { InstallerSessionSnapshot, InstallSuccessResponse } from '../api/types.js';
/** Browser failure with the Host's stable public category. */
export declare class ClientInstallError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** Parse the untrusted session response from the Host route. */
export declare function parseInstallerSession(value: unknown): InstallerSessionSnapshot;
/** Parse a successful install response without trusting package metadata fields. */
export declare function parseInstallSuccess(value: unknown): InstallSuccessResponse;
/** Fetch a fresh per-process token and upload constraints. */
export declare function loadInstallerSession(signal: AbortSignal): Promise<InstallerSessionSnapshot>;
/** Upload and install one raw npm tarball through the current session. */
export declare function installOfflinePackage(file: File, session: InstallerSessionSnapshot, signal: AbortSignal): Promise<InstallSuccessResponse>;
//# sourceMappingURL=api.d.ts.map