import type { Context } from '@deepseek-ai/cordis';
import { Config, type Config as PluginConfig } from './config.js';
export declare const name = "dsh-offline-plugin-installer";
export declare const inject: string[];
export { Config };
export type { PluginConfig };
/** Register the loopback installer routes and their shared lifecycle owners. */
export declare function apply(ctx: Context, config: PluginConfig): Promise<void>;
//# sourceMappingURL=index.d.ts.map