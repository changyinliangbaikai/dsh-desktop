/** Serializes upload plus installation and supplies one unload cancellation signal. */
export declare class InstallCoordinator {
    #private;
    /** Run one full request or fail before its body is read when another install owns the slot. */
    run<T>(task: (signal: AbortSignal) => Promise<T>, requestSignal: AbortSignal): Promise<T>;
    /** Cancel and await the active request during plugin unload. */
    dispose(): Promise<void>;
}
//# sourceMappingURL=coordinator.d.ts.map