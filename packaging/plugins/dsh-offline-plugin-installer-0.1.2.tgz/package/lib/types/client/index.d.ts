/** Browser half: an offline installation tab in the standard Plugins settings section. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type OfflineInstallerLocaleKey } from './locales.js';
export type { OfflineInstallerPageInjected, OfflineInstallerPageProps } from './OfflineInstallerPage.js';
export type { OfflineInstallerLocaleKey } from './locales.js';
export { ClientInstallError, parseInstallerSession, parseInstallSuccess } from './api.js';
export declare const NS = "settings.offlinePluginInstaller";
export declare const inject: string[];
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.offlinePluginInstaller': OfflineInstallerLocaleKey;
    }
}
/** Contribute the localized page without importing Host runtime values. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map