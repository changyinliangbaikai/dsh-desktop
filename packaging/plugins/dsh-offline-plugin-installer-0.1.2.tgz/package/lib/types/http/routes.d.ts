import type { WebRoute } from '@deepseek-ai/dsh-host-webserver';
import type { InstallerSessionSnapshot } from '../api/types.js';
import { InstallCoordinator } from '../install/coordinator.js';
import { OfflinePackageInstaller } from '../install/installer.js';
import { ArchiveStore } from '../store/archive-store.js';
export { INSTALLER_SESSION_ROUTE, INSTALLER_UPLOAD_ROUTE } from './paths.js';
/** Host dependencies for the two exact loopback routes. */
export interface InstallerRouteDependencies {
    readonly token: string;
    readonly session: InstallerSessionSnapshot;
    readonly maxUploadBytes: number;
    readonly coordinator: Pick<InstallCoordinator, 'run'>;
    readonly store: Pick<ArchiveStore, 'createIncomingPath' | 'discardIncoming'>;
    readonly installer: Pick<OfflinePackageInstaller, 'install'>;
    warn(error: unknown): void;
}
/** Create the session and upload routes without registering them globally. */
export declare function createInstallerRoutes(dependencies: InstallerRouteDependencies): readonly WebRoute[];
//# sourceMappingURL=routes.d.ts.map