import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { InstallerSessionSnapshot, InstallSuccessResponse } from '../api/types.js';
export interface OfflineInstallerPageInjected {
    readonly loadSession: (signal: AbortSignal) => Promise<InstallerSessionSnapshot>;
    readonly installPackage: (file: File, session: InstallerSessionSnapshot, signal: AbortSignal) => Promise<InstallSuccessResponse>;
}
export type OfflineInstallerPageProps = PropsRuntime<'settings.plugins.tab'> & PropsLocale<'settings.offlinePluginInstaller'> & InjectFace<OfflineInstallerPageInjected>;
/** Explicit upload-and-install tab in Settings > Plugins. */
export declare function OfflineInstallerPage(props: OfflineInstallerPageProps): ReactNode;
//# sourceMappingURL=OfflineInstallerPage.d.ts.map