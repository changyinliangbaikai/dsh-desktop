/** Use the published operation shared by `dsh plugin`, with the active launcher. */
import type { ProfileContext } from '@deepseek-ai/dsh-app-boot';
import type { CliResult } from './cli-runner.js';
export declare class ProfilePackageRunner {
    private readonly profile;
    private readonly timeoutMs;
    private readonly outputBytes;
    private active;
    constructor(profile: ProfileContext, timeoutMs: number, outputBytes: number);
    add(archive: string, signal: AbortSignal): Promise<CliResult>;
    dispose(): Promise<void>;
}
//# sourceMappingURL=profile-runner.d.ts.map